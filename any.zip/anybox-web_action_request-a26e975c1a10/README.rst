Web notification for OpenERP v8
===============================
